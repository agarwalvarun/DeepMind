#ifndef BINARY_TREE_H
#define BINARY_TREE_H
#include"BinaryTreeNode.h"
#include<iostream>
#include<queue>
#include<stack>
using namespace std;
/*template <typename T, typename V>
struct pair {
    T first;
    V second;
};*/
template <typename T>
class BinaryTree {
    BinaryTreeNode<T> * root;
    public:
    BinaryTree() : root(0){}
    void createTree() {
        T ele; char choice;
        cout << "Enter data for root node";
        cin >> ele;
        root = new BinaryTreeNode<T>(ele);
        queue<BinaryTreeNode<T>*> Q;
        Q.push(root);
        while(!Q.empty()) {
            BinaryTreeNode<T> * temp = Q.front();
            Q.pop();
            cout << "Is there a left node of " << temp->data <<" (y/n) ";
            cin >> choice;
            if (choice == 'y' || choice == 'Y') {
                cout << "Enter data for left node";
                cin >> ele;
                temp->left = new BinaryTreeNode<T>(ele);
                Q.push(temp->left);
            }
            cout << "Is there a right node of " << temp->data <<" (y/n) ";
            cin >> choice;
            if (choice == 'y' || choice == 'Y') {
                cout << "Enter data for right node";
                cin >> ele;
                temp->right = new BinaryTreeNode<T>(ele);
                Q.push(temp->right);
            }
        }
    }
    void printTree() {
        if (!root) return;
        queue<BinaryTreeNode<T>*> Q;
        Q.push(root);
        Q.push(NULL);
        while(!Q.empty()) {
            BinaryTreeNode<T> * temp = Q.front();
            Q.pop();
            if (temp == NULL) {
                if (!Q.empty()) {
                    cout << endl;
                    Q.push(NULL);
                }
                continue;
            }
            cout << temp->data << " ";
            if (temp->left) Q.push(temp->left);
            if (temp->right) Q.push(temp->right);
        }
        cout << endl;
    }
    void printPreOrder() {
        printPreOrderHelper(root);
        cout << endl;
    }
    int height() {
        return heightofNode(root);
    }
    BinaryTreeNode<T> *largest() {
        return largestNode(root);
    }
    void printAtDepthK(int K) {
        if (K < 0) return;
        printNodesAtDepthK(root, K);
        cout << endl;
    }
    BinaryTreeNode<T> * findLCA(T e1, T e2) {
        stack<BinaryTreeNode<T> *> S1, S2;
        getAncestorsInStack(root, e1, S1);
        getAncestorsInStack(root, e2, S2);
        BinaryTreeNode<T> * ancestor = NULL;
        while (!S1.empty() && !S2.empty() && S1.top() == S2.top()) {
            ancestor = S1.top();
            S1.pop();
            S2.pop();
        }
        return ancestor;
    }
    int diameter() {
        return diameterofANode(root).first;
    }
    private:
    static bool getAncestorsInStack(BinaryTreeNode<T> *root, T ele, stack<BinaryTreeNode<T> *> & S) {
        if (!root) {
            return false;
        }
        if (root->data == ele) {
            return true;
        }
        int ans = getAncestorsInStack(root->left, ele, S);
        if (ans) {
            S.push(root);
            return true;
        }
        ans = getAncestorsInStack(root->right, ele, S);
        if (ans) {
            S.push(root);
        }
        return ans;
    }
    static void printPreOrderHelper(BinaryTreeNode<T> * root) {
        if (!root) return;
        cout << root->data << " ";
        printPreOrderHelper(root->left);
        printPreOrderHelper(root->right);
        return;
    }
    static int heightofNode(BinaryTreeNode<T> * root) {
        if(!root) return -1;
        int lh = heightofNode(root->left);
        int rh = heightofNode(root->right);
        return max(lh, rh) +1;
    }
    static BinaryTreeNode<T>* largestNode(BinaryTreeNode<T> *root) {
        if (root == 0) {
            return root;
        }
        BinaryTreeNode<T> * largest = root;
        BinaryTreeNode<T> * leftLargest = largestNode(root->left);
        if (leftLargest && leftLargest->data > largest->data) {
            largest = leftLargest;
        }
        BinaryTreeNode<T> * rightLargest = largestNode(root->right);
        if (rightLargest && rightLargest->data > largest->data) {
            largest = rightLargest;
        }
        return largest;
    }
    static void printNodesAtDepthK(BinaryTreeNode<T> * root, int K) {
        if (!root) return;
        if(K == 0) {
            cout << root->data << " ";
            return;
       }
        printNodesAtDepthK(root->left, K-1);
        printNodesAtDepthK(root->right, K-1);
        return;
    }
    static pair<int,int> diameterofANode(BinaryTreeNode<T> *root) {
        if (!root) return make_pair(0, -1);
        pair<int, int> left = diameterofANode(root->left);
        pair<int, int> right = diameterofANode(root->right);
        int ld = left.first, rd = right.first, lh = left.second, rh = right.second;
        int d = max(ld, max(rd, lh+rh+1));
        int h = max(lh,rh)+1;
        return make_pair(d, h);
    }
    static BinaryTreeNode<T> * findElement(BinaryTreeNode<T> *root, T ele) {
        if (!root) return NULL;
        if (root->data == ele) return root;
        BinaryTreeNode<T> * la = findElement(root->left, ele);
        if (la) return la;
        BinaryTreeNode<T> *ra = findElement(root->right, ele);
        if (ra) return ra;
        return NULL;
    }
};
int max(int a, int b) {
    return a > b ? a : b;
}
#endif

