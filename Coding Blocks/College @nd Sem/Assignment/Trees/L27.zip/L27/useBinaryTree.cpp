#include<iostream>
#include"BinaryTree.h"
using namespace std;
int main() {
    BinaryTree<int> T;
    T.createTree();
    
    cout << "Level Order Traversal" << endl;
    T.printTree();

    cout << "Pre Order Traversal" << endl;

    T.printPreOrder();

    cout << "Diameter of Tree is " << T.diameter() << endl;

    cout << "Largest Node in the tree is with data " << T.largest()->data << endl;

    cout << "height of the tree is " << T.height() << endl;

    cout << "Elements at depth 2 are ";
    T.printAtDepthK(2);

    cout << T.findLCA(1,7)->data << endl;
    cout << T.findLCA(1,13)->data << endl;
    cout << T.findLCA(14,13)->data << endl;
    cout << T.findLCA(13,14)->data << endl;
    cout << T.findLCA(4,7)->data << endl;
    BinaryTreeNode<int> * ans = T.findLCA(1,20);
    if (ans) {
        cout << ans->data << endl;
    } else {
        cout << " You moron!!! " << endl;
    }
    return 0;
}
